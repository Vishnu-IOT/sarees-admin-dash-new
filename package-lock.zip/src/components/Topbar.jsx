import React from 'react';
import { IconSearch } from './icons.jsx';

export default function Topbar({ eyebrow, title, search, onSearchChange, searchPlaceholder = 'Search…' }) {
  return (
    <header className="topbar">
      <div className="topbar-titles">
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
      </div>
      <div className="topbar-right">
        {onSearchChange && (
          <div className="topbar-search">
            <IconSearch />
            <input
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={searchPlaceholder}
            />
          </div>
        )}
      </div>
    </header>
  );
}
